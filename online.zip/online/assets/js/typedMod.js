
  $(function(){
      $(".element").typed({
        strings: ["Failure to plan is planning to fail.",
                  "Set targets that you can achieve at the end of the period.",
                  "Through target setting, you will be able to estimate your business perfomance."],
        typeSpeed: 10
      });
  });