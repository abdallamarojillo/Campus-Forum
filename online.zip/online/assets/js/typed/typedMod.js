
  $(function(){
      $(".element").typed({
        strings: ["Experience a Secure Online Business Transactions Management System.",
                  "Easily account for all business transactions you make.",
                  "Secure and Reliable usage.."],
        typeSpeed: 15
      });
  });