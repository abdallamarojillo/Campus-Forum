<?php
define("SERVER_NAME","localhost");
define("DB_USER","root");
define("DB_PASS","");
define("DB_NAME","dtcms");

?>