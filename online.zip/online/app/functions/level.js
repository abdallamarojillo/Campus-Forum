$('#notifications').hide();
$('#addUser').hide();
$('#viewUsers').hide();
$('#manageUsers').hide();
$('#al').hide(); //access logs
$('#stock').hide();
$('#worth').hide();
$('#fb').hide();

                  