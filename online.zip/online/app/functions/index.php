<?php
header("Location:../../");
?>