<?php

?>
<html>
    <head>
        <title>test</title>
    <script>

</script>
    </head>
<body>
 <form id="test" name="test">
    Value1 :<input type="number" name="value1" id="value1"> <br/>
    Value2 :<input type="number" name="value2" id="value2"> <br/>
    <input type="submit" name="submit">
</form>   
</body>
</html>
