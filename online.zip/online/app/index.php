<?php
header("Location:../");

?>