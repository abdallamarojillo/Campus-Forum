<html>
    <head>
        <body>
            <button type="submit">Submit Button</button>
        </body>
    </head>
</html>